export default function StatCard({ icon:Icon, label, value, change, tone='teal', note }) {
  return <article className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={20}/></div><div className="stat-copy"><span>{label}</span><strong>{value}</strong><small className="stat-change">{change} <em>{note}</em></small></div></article>
}