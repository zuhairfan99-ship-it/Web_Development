export const initialPatients = [
  { id:'PT-1048', name:'Amelia Carter', age:32, gender:'Female', phone:'+1 202 555 0142', email:'amelia.carter@example.com', condition:'Migraine', doctor:'Dr. Ethan Brooks', status:'Active', joined:'2026-11-02', initials:'AC', color:'peach' },
  { id:'PT-1047', name:'Noah Williams', age:45, gender:'Male', phone:'+1 202 555 0178', email:'noah.w@example.com', condition:'Hypertension', doctor:'Dr. Sophia Chen', status:'Active', joined:'2026-11-01', initials:'NW', color:'blue' },
  { id:'PT-1046', name:'Olivia Martinez', age:27, gender:'Female', phone:'+1 202 555 0126', email:'olivia.m@example.com', condition:'Annual checkup', doctor:'Dr. Ethan Brooks', status:'Pending', joined:'2026-10-30', initials:'OM', color:'lavender' },
  { id:'PT-1045', name:'Liam Anderson', age:61, gender:'Male', phone:'+1 202 555 0193', email:'liam.a@example.com', condition:'Cardiac review', doctor:'Dr. Aisha Rahman', status:'Active', joined:'2026-10-28', initials:'LA', color:'mint' },
  { id:'PT-1044', name:'Ava Thompson', age:38, gender:'Female', phone:'+1 202 555 0114', email:'ava.t@example.com', condition:'Allergy', doctor:'Dr. Sophia Chen', status:'Inactive', joined:'2026-10-25', initials:'AT', color:'gold' },
  { id:'PT-1043', name:'Ethan Wilson', age:19, gender:'Male', phone:'+1 202 555 0165', email:'ethan.w@example.com', condition:'Sports injury', doctor:'Dr. James Patel', status:'Active', joined:'2026-10-22', initials:'EW', color:'blue' }
]
export const initialDoctors = [
  { id:'DR-201', name:'Dr. Ethan Brooks', specialty:'Neurology', experience:'12 years', availability:'Available', patients:128, initials:'EB', color:'mint' },
  { id:'DR-202', name:'Dr. Sophia Chen', specialty:'Cardiology', experience:'9 years', availability:'In consultation', patients:96, initials:'SC', color:'lavender' },
  { id:'DR-203', name:'Dr. Aisha Rahman', specialty:'Pediatrics', experience:'15 years', availability:'Available', patients:154, initials:'AR', color:'peach' },
  { id:'DR-204', name:'Dr. James Patel', specialty:'Orthopedics', experience:'7 years', availability:'Off duty', patients:82, initials:'JP', color:'gold' }
]
export const initialAppointments = [
  { id:'AP-301', patient:'Amelia Carter', doctor:'Dr. Ethan Brooks', date:'2026-11-10', time:'09:30 AM', type:'Follow-up', status:'Confirmed' },
  { id:'AP-302', patient:'Noah Williams', doctor:'Dr. Sophia Chen', date:'2026-11-10', time:'10:15 AM', type:'Consultation', status:'Pending' },
  { id:'AP-303', patient:'Olivia Martinez', doctor:'Dr. Ethan Brooks', date:'2026-11-10', time:'11:00 AM', type:'Checkup', status:'Confirmed' },
  { id:'AP-304', patient:'Liam Anderson', doctor:'Dr. Aisha Rahman', date:'2026-11-11', time:'01:30 PM', type:'Review', status:'Completed' },
  { id:'AP-305', patient:'Ava Thompson', doctor:'Dr. Sophia Chen', date:'2026-11-12', time:'03:00 PM', type:'Consultation', status:'Pending' }
]
export const initialInvoices = [
  { id:'INV-0081', patient:'Amelia Carter', service:'Neurology consultation', date:'2026-11-09', amount:180, status:'Paid' },
  { id:'INV-0080', patient:'Noah Williams', service:'Cardiac screening', date:'2026-11-08', amount:320, status:'Unpaid' },
  { id:'INV-0079', patient:'Liam Anderson', service:'Follow-up review', date:'2026-11-07', amount:120, status:'Paid' }
]